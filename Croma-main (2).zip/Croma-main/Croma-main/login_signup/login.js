function logindata() {
    return `

    <div class="cross">X</div>
    <div class="signintochroma">
        Sign in to Croma.Com
    </div>
    <div class="trackyour">
        Track your orders,get exclusive offers,redeem points and more
    </div>

    <div class="mobino">
        <input type="text" maxlength="25" id="mobileno" placeholder="Enter Your Mobile Number/Email">
    </div>
    <div class="butt">
        <button>SEND OTP</button>
    </div>
    <div class="keepdist">
        <input type="checkbox" name="" id="" checked = "checked">
        <h4>Keep me signed in</h4>
    </div>

    <div class="dont">
        <h4>Don't have an account? </h4>
        <a href="../login_signup/profile.html">Create now</a> 
    `;
    
    
}

export default logindata;