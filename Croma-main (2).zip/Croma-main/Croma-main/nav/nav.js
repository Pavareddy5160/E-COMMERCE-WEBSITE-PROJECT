function nav() {
    return `<div class="left">
    <a class="brand" href="../index.html">
      <img
        src="https://www.croma.com/assets/images/croma_logo_dark.png"
        alt=""
    /></a>
    <center class="menu">
      <a ><i class="fa-solid fa-bars"></i>Menu </a>
      <div class="dropdown">
        <div class="dropdownleft">
          <h3>SHOP BY CATEGORY</h3>
          <div>
            Televisions & Accessoriess&nbsp<i
              class="fa-solid fa-caret-right"
            ></i>
          </div >
          <div onclick = 'location.href = "../croma product page/Electronics.html"'>Home&nbsp <i class="fa-solid fa-caret-right"></i></div>
          <div onclick = 'location.href = "../croma product page/Electronics.html"'>Appliances&nbsp <i class="fa-solid fa-caret-right"></i></div>
          <div >
            Phones and Wearables&nbsp
            <i class="fa-solid fa-caret-right"></i>
          </div>
          <div>
            Computers & Tablets&nbsp <i class="fa-solid fa-caret-right"></i>
          </div>
          <div>
            Kitchen Appliances&nbsp <i class="fa-solid fa-caret-right"></i>
          </div>
          <div>
            Audio & Video&nbsp <i class="fa-solid fa-caret-right"></i>
          </div>
          <div>
            Health & Fitness&nbsp <i class="fa-solid fa-caret-right"></i>
          </div>
          <div>
            Grooming & Personal Care&nbsp
            <i class="fa-solid fa-caret-right"></i>
          </div>
          <div>
            Cameras & Accessories&nbsp
            <i class="fa-solid fa-caret-right"></i>
          </div>
          <div>
            Smart Devices&nbsp <i class="fa-solid fa-caret-right"></i>
          </div>
          <div>Gaming&nbsp <i class="fa-solid fa-caret-right"></i></div>
        </div>

        <div class="dropdownright">
          <div>
            <div>
              <p>LED TVs</p>
              <p>QLED TVs</p>
              <p>4K Ultra HD TVs</p>
              <p>8K Ultra HD TVs</p>
              <p>Smart TVs</p>
              <p>Full HD TVs</p>
              <p>HD Ready TVs</p>
              <p>Andriod Smart TVs</p>
              <p>Large Screen TVs</p>
              <p>Medium Screen TVs</p>
              <p>Small Screen TVs</p>
              <p>Croma LED TVs</p>
              <p>Gaming TVs</p>
              <p>TV Accessories</p>
              <p>TV Wall Mount & Stands</p>
              <p>Other TV Accessories</p>
              <p>TV Radiation</p>
              <p>Protection Chips</p>
            </div>
            <div>
              <p>Devices</p>
              <p>Projectrs</p>
              <p>Long Throw</p>
              <p>short Throw</p>
              <p>Projectors throw</p>
              <p>HD Projectors</p>
              <p>Full HD</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Ultra HD 4K</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>HD Projectors</p>
              <p>LED TVs</p>
            </div>
          </div>

          <div>
            <div>
              <p>Washing Machines</p>
              <p>Refrigerator</p>
              <p>Air</p>
              <p>Air Purifiers</p>
              <p>Car Air purifiers</p>
              <p>Air Filters</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>coolers</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Table fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Protectors</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Pedestal Fans</p>
            </div>
          </div>

          <div>
            <div>
              <p>Mobile Phones</p>
              <p>Android Phones</p>
              <p>Air</p>
              <p>Iphones</p>
              <p>Car Air purifiers</p>
              <p>Air Filters</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Telephones</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Fitnes Trackers</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Smart Watches</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Bands</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>coolers</p>
              <p>VR Headsets</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Table fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Pop Sockets</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Pedestal Fans</p>
            </div>
          </div>

          <div>
            <div>
              <p>Laptops</p>
              <p>Windows</p>
              <p>Air</p>
              <p>Air Purifiers</p>
              <p>Laptops Ultra Thin</p>
              <p>Air Filters</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Tablets</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>coolers</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Table fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Protectors</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Pedestal Fans</p>
            </div>
          </div>

          <div>
            <div>
              <p>Washing Machines</p>
              <p>Refrigerator</p>
              <p>Air</p>
              <p>Air Purifiers</p>
              <p>Car Air purifiers</p>
              <p>Air Filters</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>coolers</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Table fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Protectors</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Pedestal Fans</p>
            </div>
          </div>

          <div>
            <div>
              <p>Washing Machines</p>
              <p>Refrigerator</p>
              <p>Air</p>
              <p>Air Purifiers</p>
              <p>Car Air purifiers</p>
              <p>Air Filters</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>coolers</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Table fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Protectors</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Pedestal Fans</p>
            </div>
          </div>

          <div>
            <div>
              <p>Washing Machines</p>
              <p>Refrigerator</p>
              <p>Air</p>
              <p>Air Purifiers</p>
              <p>Car Air purifiers</p>
              <p>Air Filters</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>coolers</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Table fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Protectors</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Pedestal Fans</p>
            </div>
          </div>

          <div>
            <div>
              <p>Washing Machines</p>
              <p>Refrigerator</p>
              <p>Air</p>
              <p>Air Purifiers</p>
              <p>Car Air purifiers</p>
              <p>Air Filters</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>coolers</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Table fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Protectors</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Pedestal Fans</p>
            </div>
          </div>

          <div>
            <div>
              <p>Washing Machines</p>
              <p>Refrigerator</p>
              <p>Air</p>
              <p>Air Purifiers</p>
              <p>Car Air purifiers</p>
              <p>Air Filters</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>coolers</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Table fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Protectors</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Pedestal Fans</p>
            </div>
          </div>

          <div>
            <div>
              <p>Washing Machines</p>
              <p>Refrigerator</p>
              <p>Air</p>
              <p>Air Purifiers</p>
              <p>Car Air purifiers</p>
              <p>Air Filters</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>coolers</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Table fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Protectors</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Pedestal Fans</p>
            </div>
          </div>

          <div>
            <div>
              <p>Washing Machines</p>
              <p>Refrigerator</p>
              <p>Air</p>
              <p>Air Purifiers</p>
              <p>Car Air purifiers</p>
              <p>Air Filters</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>coolers</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Table fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Protectors</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Pedestal Fans</p>
            </div>
          </div>

          <div>
            <div>
              <p>Washing Machines</p>
              <p>Refrigerator</p>
              <p>Air</p>
              <p>Air Purifiers</p>
              <p>Car Air purifiers</p>
              <p>Air Filters</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>coolers</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Table fans</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
            </div>
            <div>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Protectors</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>LED TVs</p>
              <p>Pedestal Fans</p>
            </div>
          </div>
        </div>
      </div>
    </center>
  </div>
  <div class="right">
    <a class="search"
      ><input type="text" placeholder="What are you looking for ?" />
      <button><i class="fa-solid fa-magnifying-glass"></i></button>
    </a>
      <a class="user">SIGN IN</a>
    <a href="../layouts/cart.html"
      ><i class="fa-solid fa-cart-shopping"></i>
      <div class="cartcount">0</div>
      <p class="cart">CART</p></a
    >
  </div>`;
}
export default nav;