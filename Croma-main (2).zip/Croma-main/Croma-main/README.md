# Croma
Cromā is an Indian retail chain of consumer electronics and durables run by Infiniti Retail, a subsidiary of the Tata Group.
This repositry is the clone of this website....
Live-link-->https://stupendous-pothos-c1584a.netlify.app/
