module.exports = {
    content: ["./layouts/*.html"],
    theme: {
        extend: {},
    },
    plugins: [],
}